<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	function __construct() {
        parent::__construct();
    }

	public function login(){
		$data['title'] = 'Admin Login';
		if($this->input->post('submit')){
			$this->form_validation->set_rules('username', 'Username', 'trim|required');
			$this->form_validation->set_rules('password', 'Password', 'trim|required');
			$post = $this->input->post();
			if ($this->form_validation->run() == FALSE) {
				$this->load->view('admin/login');
			}else{
				$username = $this->input->post('username');
				$pass = MD5($this->input->post('password'));
				$where = array('username' =>$username,'password' =>$pass);
				$user_details = $this->GeneralModel->getRowDataWithWhere('*','users',$where);
				if($user_details){
					$this->session->set_userdata('username', $user_details->username);
					$this->session->set_userdata('login_id', $user_details->id);
					$this->session->set_flashdata('message',LOGIN_SUCEESS );
					redirect('admin/profile');
				}else{
					$this->session->set_flashdata('error',INVAILID_LOGIN );
					redirect('admin/login');
				}
			}
		}else{
			$this->load->view('admin/login', $data);
		}
	}


	public function profile(){
		if(!$this->session->userdata('login_id')){
            redirect('admin/login');
        }
		$where = array('id !=' => $this->session->userdata('login_id'));
		$data['title'] = 'Welcome '.$this->session->userdata('username');
		$this->load->view('admin/header', $data);
		$this->load->view('admin/profile', $data);	
	}

	function create_form(){
		if(!$this->session->userdata('login_id')){
            redirect('admin/login');
        }
		$where = array('id !=' => $this->session->userdata('login_id'));
		$data['title'] = 'Welcome '.$this->session->userdata('username');
		$this->load->view('admin/header', $data);
		$this->load->view('admin/forms', $data);
	}

	function create_form_process(){
		if(!$this->session->userdata('login_id')){
            redirect('admin/login');
        }
		$total_form = count($this->input->post('form_title'));
		$i = 0;
		foreach ($this->input->post('form_title') as $value) {
			$data = array(
				'form_name' => $value,
			);

			$form_id = $this->GeneralModel->insertData('forms', $data);
			$filed_counter = $this->input->post('form_'.$i);
			for($j = 0; $j<$filed_counter; $j++){
				$inner_data = array(
					'form_id' => $form_id,
					'lable_name' =>  $this->input->post('lable_name_'.$i)[$j],
					'field_name' => $this->input->post('field_name_'.$i)[$j],
					'field_type' => $this->input->post('field_type_'.$i)[$j],
					'options' => $this->input->post('options_'.$i)[$j],
					'required' => $this->input->post('required_'.$i)[$j]
				);
				$insert_id = $this->GeneralModel->insertData('forms_details', $inner_data);
			}
			$i++;
		}

		$this->session->set_flashdata('message','Form created succesfully');
		redirect('admin/profile');
	}

	function logout(){
		$this->session->sess_destroy();
    	redirect('admin/login');
	}	
}
