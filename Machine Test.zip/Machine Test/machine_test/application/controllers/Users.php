<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	function __construct() {
        parent::__construct();
    }

	public function forms(){
		$data['title'] = 'Forms';
		$data['forms'] = $this->GeneralModel->getAllRowDataWithWhereOrderBy('id,form_name','forms',array('id !=' => 0), 'id','ASC');
		if($this->input->post('submit')){ 
			$data['forms_details'] = $this->GeneralModel->getAllRowDataWithWhereOrderBy('*','forms_details',array('form_id' => $this->input->post('display_form')), 'id','ASC');
		}
		$this->load->view('users/header', $data);
		$this->load->view('users/forms', $data);	
	}


	
}
