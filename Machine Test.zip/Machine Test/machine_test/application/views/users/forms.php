<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

			<div class="chat-details">
			<h3 class=" text-center chat-name">&nbsp;</h3>
			<div class="messaging">
				<div class="inbox_msg">
					
					<div class="mesgs">
						
						<div class="welcome-users">
							<div class="row">
								<div class="col-sm-12 text-center">
									<h1>Welcome, Users</h1>
									<br/><br/>
									<form method="post" name="forms">
									<div class="row">
										<div class="col-md-3">
												<lable> Select Form </lable>
											</div>	
											<div class="col-md-4">
												<select class="form-control" name="display_form" required="">
													<option value="">Select</option>
													<?php 
														foreach($forms as $value){ 
															$class = ($value['id'] == $_POST['display_form'])?'selected':'';
															?>
															<option value="<?php echo $value['id']; ?>" <?php echo $class; ?> ><?php echo $value['form_name']; ?></option>
														<?php }	

													?>
												</select>
											</div>
											<div class="col-md-3">
												<input type="submit" name="submit" class="btn btn-primary">
												<a href="<?php  echo base_url('index.php/admin/login'); ?>" class="btn btn-primary">Aamin Login</a>
											</div>	

										<br/><br/>
										<br/><br/>
									</div>
									</form>

									<?php
										if($this->input->post('submit')){ ?>
												<form class="front-end-form" action="" method="post">
												<div class="form-row">
													<?php 
													foreach ($forms_details as $value) { ?>
														
														<div class="form-group col-md-12">
															<label for="inputEmail4"><?php echo $value['lable_name']; ?></label>
															<?php
																switch ($value['field_type']) {
																	case 'text':
																		echo '<input type="text" class="form-control" placeholder="'.$value['lable_name'].'" name="'.$value['field_name'].'">';
																		break;
																	
																	case 'number':
																	echo '<input type="number" class="form-control" placeholder="'.$value['lable_name'].'" name="'.$value['field_name'].'">';
																	break;

																	case 'select':
																	echo '<select class="form-control"  name="'.$value['field_name'].'" >';
																		$optios = explode(',', $value['options']);
																		foreach ($optios as $value2){
																			echo '<option value="'.$value2.'">'.$value2.'</option>';
																		}
																	echo '</select>';
																	break;

																	case 'radio':
																	$optios = explode(',', $value['options']);
																		foreach ($optios as $value2){
																			echo '<input  class="form-control" type="radio" name="'.$value['field_name'].'" value="'.$value2.'">'.$value2;
																	}
																	break;


																	case 'check':
																	$optios = explode(',', $value['options']);
																		foreach ($optios as $value2){
																			echo '<input  class="form-control" type="checkbox" name="'.$value['field_name'].'" value="'.$value2.'">'.$value2;
																	}
																	break;

																	default:
																		break;
																}


															?>
															
														</div>
												<?php } ?>
												<button type="submit" class="btn btn-primary">Submit</button>
												<br />
												
												</div>
												</form>

												
										<?php } ?>	
								</div>	
							</div>		
						</div>	
					</div>
				</div>
			</div>
			</div>
		</div>
	</body>
</html>
