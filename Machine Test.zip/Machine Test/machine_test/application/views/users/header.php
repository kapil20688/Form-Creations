<!DOCTYPE html>
<html lang="en">
	<head>
		<title><?php echo $title; ?></title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
		<link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css" />
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" />
		<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" type="text/css" rel="stylesheet" >
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
		
		<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
		
	</head>
	<body>
		
		<div class="container">
			<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
				
				<ul class="navbar-nav">
					<li class="nav-item">
						<a class="nav-link" href="#"><?php echo $this->session->userdata('username'); ?></a>
					</li>
				</ul>
				<div class="pull-right logout">
				</div>
			</nav>
			<?php 
			if($this->session->flashdata('message')){ ?>
				<div class="alert alert-success in alert-dismissable hide_error" style="margin-top:18px;">
				<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
				<strong>Success!</strong> <?php echo $this->session->flashdata('message'); ?> .
				</div>	
			<?php } ?>
			<div class="hidden-variable">
				<input type="hidden" class="base_url" value="<?php echo base_url(); ?>">
				<input type="hidden" class="user_id" value="<?php echo $this->session->userdata('login_id'); ?>">
			</div>