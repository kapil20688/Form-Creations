<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title><?php echo $title; ?></title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css" />
		<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" />
		<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
	</head>
	<body>

		<div class="container">
			<div class="row">
				<aside class="col-sm-4 offset-sm-4">
					<div class="login-form">
						<div class="card">
							<article class="card-body">
								<h4 class="card-title mb-4 mt-1">Sign in</h4>
								
								<hr>
								<?php 
								if($this->session->flashdata('error')){ ?>
									<div class="alert alert-danger in alert-dismissable hide_error" style="margin-top:18px;">
									<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
									<strong>Error!</strong> <?php echo $this->session->flashdata('error'); ?> .
									</div>	
								<?php } ?>
								<?php 
								if($this->session->flashdata('message')){ ?>
								<div class="alert alert-success in alert-dismissable hide_error" style="margin-top:18px;">
								<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
								<strong>Success!</strong> <?php echo $this->session->flashdata('message'); ?> .
								</div>	
								<?php } ?>
								<form class="login-forms" method="post" autocomplete="off" action="<?php echo base_url(); ?>index.php/admin/login">
									<div class="form-group">
										<input name="username" class="form-control" placeholder="Username " type="text">
									</div>
									<div class="form-group">
										<input name="password" class="form-control" placeholder="******" type="password">
									</div>                                    
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<button type="submit" class="btn btn-primary btn-block" name="submit" value="Login"> Login  </button>
												<a href="<?php echo base_url(); ?>index.php/users/forms" class="btn btn-primary btn-block">User</a>
											</div>
										</div>
									</div>                                                               
								</form>
									
							</article>
						</div> 
					</div>
				</aside>
			</div>
		</div> 
	</body>
</html>

