<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

			<div class="chat-details">
			<h3 class=" text-center chat-name">&nbsp;</h3>
			<div class="messaging">
				<div class="inbox_msg">
					
					<div class="mesgs">
						
						<div class="welcome-users">
							<div class="row">
								<div class="col-sm-12 text-center">
									<h1>Welcome, <?php echo $this->session->userdata('username'); ?></h1>
									<br/><br/>
									
									<div class="text-center">
										<p>You are signed as <?php echo $this->session->userdata('username'); ?></p>
									</div>
									<br/><br/>
									<div class="text-center">
										<a href="create_form" class="btn btn-primary" >Create Form</a><br/><br/>
									</div>
								</div>	
							</div>		
						</div>	
					</div>
				</div>
			</div>
			</div>
		</div>
	</body>
</html>
