<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

			<div class="chat-details">
			<h3 class=" text-center chat-name">&nbsp;</h3>
			<div class="messaging">
				<div class="inbox_msg">
					
					<div class="mesgs">
						
						<div class="welcome-users">
							<div class="row">
								<div class="col-sm-12 text-center">
									<h1>Create Form</h1>
									<br/><br/>
									<form action="" method="post">
										<div class="text-center">
											<p>Please enter number of forms : <input type="number" name="total_form" value="<?php echo (isset($_POST['total_form']))?$_POST['total_form']:''; ?>"></p>
										</div>
										<br/><br/>
										<div class="text-center">
											<input class="btn btn-primary" type="submit" name="submit" value="Create Form"><br/><br/>
										</div>
									</form>	
								</div>	
							</div>		
						</div>
						<?php
						if($this->input->post('total_form')){ ?>
							<form action="create_form_process" method="post">
							<div class="form-creations">
								<?php
								for($i=0; $i<$this->input->post('total_form'); $i++){ ?>	
								<div class="form-container form-group">
									<input type="hidden" class="form_counter" name="form_<?php echo $i; ?>" value="1" />
									<div class="row">
										<div class="col-md-6">
											<lable>Form Title</lable>&nbsp;&nbsp;&nbsp;<input class="form-control" type="text" name="form_title[]" required="required">
										</div>	
									</div>
									<div class="inner-form-colelction">	
										<div class="row inner-form">
											<div class="col-md-2">
												<lable>Lable Name</lable>&nbsp;&nbsp;&nbsp;<input class="form-control"  type="text" name="lable_name_<?php echo $i; ?>[]" required="required"/>
											</div>
											<div class="col-md-2">
												<lable>Filed Name</lable>&nbsp;&nbsp;&nbsp;<input class="form-control"  type="text" name="field_name_<?php echo $i; ?>[]" required="required"/>
											</div>	
											<div class="col-md-2">
												<lable>Field Type</lable>&nbsp;&nbsp;&nbsp;
												<select class="form-control"  name="field_type_<?php echo $i; ?>[]">
													<option value="text">Text</option>
													<option value="number">Number</option>
													<option value="select">SelectBox</option>
													<option value="radio">Radio</option>
													<option value="check">Checkbox</option>
												</select>	
											</div>
											<div class="col-md-2">
												<lable>Options</lable>&nbsp;&nbsp;&nbsp;<input class="form-control"  type="text" name="options_<?php echo $i; ?>[]" />
											</div>	
											<div class="col-md-2">	
												<lable>Required</lable>&nbsp;&nbsp;&nbsp;
												<select class="form-control"  name="required_<?php echo $i; ?>[]" required="required">
													<option value="yes">Yes</option>
													<option value="no">No</option>
													
												</select>
											</div>
											<div class="col-md-2">
												<lable>&nbsp;</lable>
												<button class="form-control add_more btn btn-primary">Add</button>
											</div>	
										</div>
									</div>	
								</div>	
							
							<?php } ?>
							</div>
							<div class="row">
								<div class="col-md-3">
									<input type="submit" class="form-control btn btn-primary" name="process" value="Submit">
								</div>
								<br/>	<br/>
						</form>
						<?php } ?>		
					</div>
				</div>
			</div>
			</div>
		</div>
	</body>
</html>
