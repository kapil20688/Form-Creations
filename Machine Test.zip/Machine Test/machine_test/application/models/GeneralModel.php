<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class GeneralModel extends CI_Model{

	function __construct(){    
		parent::__construct();
		$this->load->library('email');
	}


	/******************************** Dynamic Functuions **************************************/ 
    /*
     * this function insert data in to database tabel on basis of tabel name and data. 
     */
     
	function insertData($tabel_name, $data) {
		$this->db->insert($tabel_name, $data);
		$insert_id = $this->db->insert_id();
		return $insert_id;
	}
	
    /*
     * this function delete data from tabel on basis of tabel name and where condition. 
     */
     
	function deleteData($tabel_name, $where) {
		$this->db->where($where);
		$this->db->delete($tabel_name);
		return $this->db->affected_rows();
	}
	
    /*
     * this function return required data in array form from given tabel name . 
     */
     
	function getAllTabelData($select,$from) {
		$this->db->select($select);
		$this->db->from($from);
		$query = $this->db->get();
		return $query->result_array();
	}
	
    /*
     * this function return required data in array form from given tabel name with order by . 
     */
     
	function getAllTabelDataOrderBy($select,$from,$orderBy,$order) {
		$this->db->select($select);
		$this->db->from($from);
		$this->db->order_by($orderBy,$order);
		$query = $this->db->get();
		return $query->result_array();
	}
    
    /*
	* this function return required data in array form from given tabel name and on basis of where condition.
	*/
	
	function getAllRowDataWithWhereTwoOrderBy($select,$from,$where,$orderBy1,$order1,$orderBy2,$order2){
		$this->db->select($select);
		$this->db->from($from);
		$this->db->where($where);
		$this->db->order_by($orderBy1,$order1);
		$this->db->order_by($orderBy2,$order2);
		$query = $this->db->get();
		return $query->result_array();
	}
	
    /*
     * this function return required data in array form from given tabel name and on basis of where condition. 
     */
     
	function getAllRowDataWithWhere($select,$from,$where) {
		$this->db->select($select);
		$this->db->from($from);
		$this->db->where($where);
		$query = $this->db->get();
		return $query->result_array();
	}
	
    /*
     * this function return required data in array form from given tabel name and on basis of where condition with order by. 
     */
     
	function getAllRowDataWithWhereOrderBy($select,$from,$where,$orderBy,$order) {
		$this->db->select($select);
		$this->db->from($from);
		$this->db->where($where);
		$this->db->order_by($orderBy,$order);
		$query = $this->db->get();
		return $query->result_array();
	}
   
    /*
     * this function return required data in array form from given tabel name and on basis of where condition and or_where. 
     */
     
	function getAllRowDataWithWhereAndOrWhere($select,$from,$where,$orwhere,$orderBy,$order) {
		$this->db->select($select);
		$this->db->from($from);
		$this->db->where($where);
		$this->db->or_where($orwhere);
		$this->db->order_by($orderBy,$order);
		$query = $this->db->get();
		return $query->result_array();
	}
   
    /*
     * this function return required data in array form from given tabel name and on basis of where condition. 
     */
     
	function getAllRowDataWithTwoLikes($select,$from,$where1,$where2) {
		$this->db->select($select);
		$this->db->from($from);
		$this->db->where($where1);
		$this->db->where($where2);
		$query = $this->db->get();
		return $query->result_array();
	}
	
    /*
     * this function return number of rows . 
     */
     
	function getRowCount($select,$from,$where) {
		$this->db->select($select);
		$this->db->from($from);
		$this->db->where($where);
		$query = $this->db->get();
		return $query->num_rows();
	}
    
    /*
     * this function return number of rows with limit. 
     */
     
	function getChatResultByUsers($select,$from,$sender,$receiver,$orderBy,$order) {
		$this->db->select($select);
		$this->db->from($from);
		$this->db->where("message!= ", '');
		$this->db->where("(sender_id = {$sender} AND receiver_id = {$receiver})");
                $this->db->or_where("(receiver_id = {$sender} AND sender_id = {$receiver})");
                $this->db->order_by($orderBy,$order);
		$query = $this->db->get();
		return $query->result_array();
	}
        
        function getChatResultByGroup($select,$from,$sender,$group,$orderBy,$order) {
		$this->db->select($select);
		$this->db->from($from);
		$this->db->where("message!= ", '');
		$this->db->where("group_id", $group);
                $this->db->join('users','groups_chat.sender_id = users.id', 'inner');
                $this->db->order_by($orderBy,$order);
		$query = $this->db->get();
                return $query->result_array();
	}
    
	/*
	* this function return singal row data in form of array . 
	*/
	
	function getAllRowDataWithWhereRowArray($select,$from,$where) {
		$this->db->select($select);
		$this->db->from($from);
		$this->db->where($where);
		$query = $this->db->get();
		return $query->row_array();
	}
	
	/*
	* this function return singal row data in form of object. 
	*/

	function getRowDataWithWhere($select,$from,$where) {
		$this->db->select($select);
		$this->db->from($from);
		$this->db->where($where);
		$query = $this->db->get();
		return $query->row();
	}
	
    /*
     * this function update data on basis of where condition and tabel name. 
     */
     
	function updateTabel($fields,$tabel,$where) {
		$this->db->where($where);
		$this->db->update($tabel, $fields);
		return $this->db->affected_rows(); 
	}
	
    /*
     * this function get data on basis of join of tabel name. 
     */
     
	function joinTabel($select,$tabel1,$tabel2,$join_where,$join_type,$where,$orderBy,$order) {
		$this->db->select($select);
		$this->db->from($tabel1);
		$this->db->join($tabel2,$join_where,$join_type);
		$this->db->where($where); 
		$this->db->order_by($orderBy,$order);
		$query = $this->db->get();
		return $query->result_array();
	}
    
    /*
     * this function get data on basis of join of tabel namewith two where. 
     */
     
	function joinTabelTwoWhere($select,$tabel1,$tabel2,$join_where,$where1,$where2) {
		$this->db->select($select);
		$this->db->from($tabel1);
		$this->db->join($tabel2,$join_where);
		$this->db->where($where1);
		$this->db->where($where2);
		$query = $this->db->get();
		return $query->result_array();
	}

	function getGroupDetails($select,$from,$orderBy,$order) {
               // echo "select $select From $from WHERE (creator_id = {$this->session->userdata('login_id')}) OR participator in ({$this->session->userdata('login_id')}) order_by id asc";
		/*$this->db->select($select);
		$this->db->from($from);
		$this->db->where("(creator_id = {$this->session->userdata('login_id')})");
                $this->db->or_where_in("participator", $this->session->userdata('login_id'), TRUE);
		$this->db->order_by($orderBy,$order);
		$query = $this->db->get();
		return $query->result_array();*/
                $query = $this->db->query("select $select From $from WHERE (creator_id = {$this->session->userdata('login_id')}) OR participator in ({$this->session->userdata('login_id')})");
	
                return $query->result_array();
                }
}