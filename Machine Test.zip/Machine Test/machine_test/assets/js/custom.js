/***************** Custom Jquery File *****************/
jQuery.noConflict();
jQuery(document).ready(function(){
	var email_filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
	var base_url = jQuery('.base_url').val();
	var date_time = jQuery('.date_time').val();
	
	jQuery('form.login-forms').submit(function(e){ 
		jQuery(this).find('div.form-group').removeClass('has-error');
		jQuery(this).find('div.form-group span.error-box').remove();
		var username = jQuery(this).find('input[name="username"]');
		var password = jQuery(this).find('input[name="password"]');
		var check_valid = 0; 
		
		if(username.val() == ''){
			username.parents('div.form-group').addClass('has-error');
			jQuery(get_error_msg('please enter username')).insertAfter(username);
			check_valid = 1;
		}
		if(password.val() == ''){
			password.parents('div.form-group').addClass('has-error');
			jQuery(get_error_msg('please enter password')).insertAfter(password);
			check_valid = 1;
		}
		
		else if(password.val().length < 2){
			password.parents('div.form-group').addClass('has-error');
			jQuery(get_error_msg('password is too week')).insertAfter(password);
			check_valid = 1;
		}
		if(check_valid == 1){
			return false;
		}
	});
	

	jQuery(document).on('click', '.add_more', function(){
		var _counter = jQuery(this).parents('.form-container').find('.form_counter').val();
		_counter++;
		var _html = jQuery(this).parents('.form-container').find('.inner-form').html();
		jQuery(this).parents('.form-container').find('.inner-form-colelction').append('<div class="row inner-form">'+_html+'</div>');
		jQuery(this).parents('.form-container').find('.form_counter').val(_counter);
	});

});


function get_error_msg(msg){
	
	return '<span class="text-danger error-box">'+msg+'</span>';
}
